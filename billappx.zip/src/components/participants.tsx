"use client";

import { useParticipants } from "@/hooks/use-participants";
import { participantAtom } from "@/store/participant";
import { userAtom } from "@/store/users";
import { useAtom } from "jotai/react";
import { SearchIcon } from "lucide-react";
import * as React from "react";
import { useEffect, useState } from "react";

export default function Participants() {
  const [participant, setParticipant] = useAtom(participantAtom);
  const [limit, setLimit] = useState(false);
  const [user] = useAtom(userAtom);

  //const participants = banksIniciador;
  const [participants] = useParticipants();
  const [participantsFiltered, setParticipantsFiltered] = useState(
    participants ?? []
  );

  const filterBanks = (searchText: string) => {
    if (searchText.length < 2) {
      // Se o texto de pesquisa for menor que 2 caracteres, exiba a lista completa
      setParticipantsFiltered(participants);
    } else {
      // Caso contrário, filtre os bancos com base no customerFriendlyName
      const normalizedSearchText = searchText
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase();
      const filteredBanks = participants.filter((bank) =>
        bank.name
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toLowerCase()
          .includes(normalizedSearchText)
      );

      setParticipantsFiltered(filteredBanks);
    }
  };

  useEffect(() => {
    if (participants.length > 0) {
      setParticipantsFiltered(participants);
    }
  }, [participants]);

  //console.log("participant::", participantsFiltered);

  function onSelectParticipant(participant: any) {
    setParticipant(participant);
  }

  const onSlice = limit ? participantsFiltered.length : 8;

  return (
    <div className="shadow-[0px_0px_4px_rgba(0,0,0,0.25)] md:max-w-2xl self-center flex w-full flex-col mt-6 rounded-2xl">
      <div className="flex justify-center m-2">
        <div className="flex flex-col">
          <div className="text-base mb-5">Selecione o seu banco:</div>

          <div className="flex justify-center gap-2 md:gap-12 flex-wrap">
            {participantsFiltered.slice(0, onSlice).map((participant) => (
              <div
                key={participant.name}
                className="flex flex-col items-center min-w-20 max-w-[3.0rem] md:min-w-30 md:max-w-[7.0rem] hover:scale-110 cursor-pointer rounded-xl border p-2 bg-white duration-300"
                onClick={() => onSelectParticipant(participant)}
              >
                <img
                  loading="lazy"
                  alt={participant.name + " logo"}
                  src={
                    participant.avatar ??
                    "https://cdn.builder.io/api/v1/image/assets/TEMP/9a7955dd46dc90e87a80fdc506293cdc553b7fb13821bd38f6c163e2261b0edf?apiKey=6f65d7e2e862460c8ffb4d2909ad4de9&"
                  }
                  className="rounded-full aspect-square object-contain object-center w-28 overflow-hidden max-w-full"
                />
                <div className="text-black text-center text-xs mt-2.5">
                  {participant.name}
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-end">
            <span
              className="flex justify-start gap-3.5 mt-8 items-center cursor-pointer"
              onClick={() => setLimit(!limit)}
            >
              <img
                alt=""
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/dd9f72946254c1a2fe0c6137a21361ead8f37b5659be8da70b0a270e51e4c23b?apiKey=6f65d7e2e862460c8ffb4d2909ad4de9&"
                className="aspect-[0.73] object-contain object-center w-2 fill-teal-700 overflow-hidden shrink-0 max-w-full"
              />
              <div className="text-base leading-5 grow whitespace-nowrap mr-2">
                ver lista {limit ? "resumida" : "completa"} de bancos
              </div>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
