import { Loader } from "./loader";

export default function Invoice() {
  return (
    <div className="text-center">
      <h3 className="text-lg text-black font-bold">Aguarde.</h3>
      <p className=" text-black">Estamos conferindo os dados da Fatura.</p>
      <Loader />
    </div>
  );
}
