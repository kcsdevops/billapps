"use client";

import { useState } from "react";
import { OTP } from "@/components/otp";
import { InitPayment } from "@/components/initPayment";
import { useAtom } from "jotai/react";
import { userAtom } from "@/store/users";
import { getBankById } from "@/lib/utils";
import { participantAtom } from "@/store/participant";
import Participants from "./participants";

type props = {
  token: string;
  bank?: string;
};

export default function HomeComponent({ token, bank }: props) {
  const [activeContent, setActiveContent] = useState(1);
  const [user] = useAtom(userAtom);
  const [participant, setParticipant] = useAtom(participantAtom);
  //console.log("user", user);
  if (bank) {
    const getBank = getBankById(bank);
    if (!getBank) {
      alert("banco não encontrado");
      return;
    }
    setParticipant(getBank);
  }

  return (
    <div className="max-w-2xl md:min-w-[600px]">
      <div className="w-full p-4">
        <img
          src="https://poc.billapp.com.br/providers/cemig/logo.svg"
          alt="CEMIG"
          className="w-40 py-5 mb-2"
        />
        <h2 className="text-gray-700 font-bold text-2xl">
          Pagamento de Faturas
        </h2>
      </div>
      <div className="bg-white min-h-[400px] p-6 rounded-lg shadow-lg w-full mb-4 flex flex-col justify-between">
        {!participant.id && <Participants />}
        {participant.id && !user.documentoCliente && <OTP token={token} />}
        {user.documentoCliente && participant.id && <InitPayment />}

        <div className="flex flex-col items-center w-full my-4">
          <img src="/openfinance.png" alt="open finance" width={150} />
          <p className="text-black text-sm text-center">
            Você está em um ambiente seguro e autorizado pelo Banco Central.
          </p>
        </div>
      </div>
    </div>
  );
}
