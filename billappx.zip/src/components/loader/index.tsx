import React from "react";
import "./loader.css"; // Importando o CSS personalizado

export const Loader: React.FC = () => {
  return <div className="loader mx-auto my-5"></div>;
};
