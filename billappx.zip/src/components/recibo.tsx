export function Recibo() {
  return <p>recibo</p>;
}
