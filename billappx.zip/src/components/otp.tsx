"use client";

import { REGEXP_ONLY_DIGITS_AND_CHARS } from "input-otp";

import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { useEffect, useState } from "react";
import { loadUserData } from "@/actions/soapConnection";
import { useAtom } from "jotai/react";
import { userAtom } from "@/store/users";
import Invoice from "./invoice";

export function OTP({ token }: { token: string }) {
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState<boolean>(false);
  const [user, setUser] = useAtom(userAtom);

  async function loadData() {
    setLoading(true);
    const response: any = await loadUserData(token, value);
    console.log("response", response);
    if (response?.documentoCliente.length === 0) {
      alert("Cliente não encontrado");
      setLoading(false);
      return;
    }
    if (response?.pix.length === 0) {
      alert("Cliente sem pix cadastrado");
      setLoading(false);
      return;
    }
    if (response?.documentoCliente?.length > 2) {
      setUser(response);
      setLoading(false);
    }
  }

  useEffect(() => {
    if (value.length === 3) {
      loadData();
    }
  }, [value]);

  if (loading) {
    return <Invoice />;
  }

  return (
    <div className="text-center">
      <h3 className="text-lg text-black font-bold mb-4">
        Vamos iniciar o Pagamento.
      </h3>
      <p className="text-black">
        Para seguir, digite os <span className="font-bold">3 primeiros</span>{" "}
        números do <span className="font-bold">CPF</span> do titular.
      </p>
      <div className="flex justify-center gap-2 mt-4">
        <InputOTP
          maxLength={3}
          value={value}
          onChange={(value) => setValue(value)}
          pattern={REGEXP_ONLY_DIGITS_AND_CHARS}
          className="mt-4"
        >
          <InputOTPGroup className="gap-4">
            <InputOTPSlot
              index={0}
              className="w-16 h-16 border-2 border-green-600 rounded-lg"
            />
            <InputOTPSlot
              index={1}
              className="w-16 h-16 border-2 border-green-600 rounded-lg"
            />
            <InputOTPSlot
              index={2}
              className="w-16 h-16 border-2 border-green-600 rounded-lg"
            />
          </InputOTPGroup>
        </InputOTP>
      </div>
    </div>
  );
}
