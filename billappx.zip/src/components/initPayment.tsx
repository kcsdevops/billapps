"use client";

import { initPaymentQRCode } from "@/actions/itp-service";
import {
  convertStringToNumber,
  decode_brcode,
  getFirstName,
} from "@/lib/utils";
import { participantAtom } from "@/store/participant";
import { userAtom } from "@/store/users";
import { useAtom } from "jotai/react";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import InitPaymentStatus from "./initPaymentStatus";
import { Loader } from "./loader";
import { LoadingButton } from "./loading-button";

export function InitPayment() {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [payment_id, setPayment_id] = useState(null);
  const [redirectUrl, setRedirectUrl] = useState(null);
  const [timer, setTimer] = useState("05:00");
  const [user] = useAtom(userAtom);
  const [participant] = useAtom(participantAtom);

  useEffect(() => {
    if (payment_id) startTimer(300);
  }, [payment_id]);

  useEffect(() => {
    setIsLoading(true);
    initPaymentInitiator();
  }, []);

  async function initPaymentInitiator() {
    const parseQrcode = decode_brcode(user.pix);
    const amount = parseQrcode[54];
    if (!amount) {
      toast.error("ocoreu um erro ao ler o código pix");
      return;
    }
    try {
      //console.log("initPayment", participant, user, bill);
      const payload = {
        participantId: participant?.id,
        codePix: user.pix,
        name: user.nomeCliente,
        taxId: user.documentoCliente,
        amount: convertStringToNumber(amount),
        redirectURL: `itp/callback`,
      };
      if (process.env.NEXT_PUBLIC_APP_ENV === "development") {
        payload.taxId = "12976129819";
      }
      const id = await initPaymentQRCode(payload);
      console.log("initPayment: ID", id);
      if (id) {
        setIsLoading(false);
        setPayment_id(id);
      } else {
        toast.error("Ocorreu um erro ao iniciar o seu pagamento");
      }
    } catch (error: any) {
      toast.error(error?.message);
    } finally {
      setIsLoading(false);
    }
  }

  const startTimer = (duration: number) => {
    let timer = duration,
      minutes,
      seconds;
    const interval = setInterval(() => {
      minutes = Math.floor(timer / 60);
      seconds = timer % 60;

      minutes = minutes < 10 ? `0${minutes}` : minutes;
      seconds = seconds < 10 ? `0${seconds}` : seconds;

      setTimer(`${minutes}:${seconds}`);

      if (--timer < 0) {
        clearInterval(interval);
      }
    }, 1000);
  };

  function onRedirect() {
    window.location.assign(redirectUrl!);
  }

  console.log("redirectUrl>>>>>>", redirectUrl);

  return (
    <div className="text-center">
      <h3 className="text-lg text-black font-bold">Tudo pronto!</h3>
      {!redirectUrl && payment_id && (
        <p className="text-black my-4">
          {getFirstName(user.nomeCliente)} estamos conferindo os dados da Fatura
          e conectando o banco {participant.name}.
        </p>
      )}

      {isLoading && <Loader />}

      {!redirectUrl && payment_id && (
        <InitPaymentStatus
          setRedirectUrl={setRedirectUrl}
          payment_id={payment_id}
        />
      )}

      {redirectUrl && (
        <>
          <p className="text-black my-4">
            Agora o pagamento pode ser realizado, clique no botão abaixo para
            ser redirecionado para o seu banco.
          </p>
          <p className="text-sm mt-2 text-black">
            Tempo disponível para realizar o pagamento:{" "}
            <span className="font-semibold">{timer}</span>
          </p>
          <LoadingButton
            className="w-3/5 bg-[#00853f] mt-4"
            onClick={onRedirect}
            isLoading={isLoading}
          >
            <img src="/logo.png" alt="Pagar logo" className="h-6 w-fit" />
          </LoadingButton>
        </>
      )}
    </div>
  );
}
