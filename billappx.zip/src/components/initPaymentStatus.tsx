"use client";

import { useEffect, useState } from "react";
import { Loader } from "@/components/loader";
import { useIniciadorStatus } from "@/hooks/use-iniciador-status";

export default function InitPaymentStatus({ payment_id, setRedirectUrl }: any) {
  const [getStatus] = useIniciadorStatus(payment_id);
  const { metadata } = getStatus;
  const status = metadata?.status;
  const redirectConsentURL = metadata?.redirectConsentURL;
  const [message, setMessage] = useState("");

  console.log("paymentId metadata", getStatus, redirectConsentURL);

  const statusDict: any = {
    STARTED: "Iniciado",
    CONSENT_AWAITING_AUTHORIZATION: "Aguardando consentimento",
    CONSENT_AUTHORIZED: "Consenso autorizado",
    PAYMENT_COMPLETED: "Pagamento efetuado com sucesso",
    ENQUEUED: "aguardando ...",
    CONSENT_REJECTED: "Consenso rejeitado",
    PAYMENT_REJECTED: "Pagamento rejeitado",
    CANCELED: "Pagamento cancelado",
    ERROR: "Erro ao finalizar o pagamento por parte do banco selecionado",
    EXPIRED: "Pagamento expirado",
    PAYMENT_PENDING: "Pagamento pendente, aguardando confirmação bancária",
    PAYMENT_PARTIALLY_ACCEPTED: "Pagamento aguardando multiplas autorizações",
    PAYMENT_SETTLEMENT_PROCESSING:
      "Iniciação de pagamento aceita e processamento de pagamento iniciado",
    PAYMENT_SETTLEMENT_DEBTOR_ACCOUNT: "Crédito realizado na conta de destino",
  };

  useEffect(() => {
    if (status === "CONSENT_AWAITING_AUTHORIZATION") {
      console.log("paymentId CONSENT_AWAITING_AUTHORIZATION");
      //setRedirectUrl(redirectConsentURL);
      setTimeout(() => {
        setRedirectUrl(redirectConsentURL);
      }, 1000);
    }
    setMessage(statusDict[status]);
  }, [status]);

  return <Loader />;
}
