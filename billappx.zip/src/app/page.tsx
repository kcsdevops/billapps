import HomeComponent from "@/components/homeComponent";
import { Loader } from "@/components/loader";
import { Suspense } from "react";

export default async function Home({ searchParams }: any) {
  // get params token & bank
  const token = searchParams?.token;
  const bank = searchParams?.bank;
  console.log("token, bank", token, bank);
  // if params not token get a msg token not found
  if (!token) {
    return <h1 className="mt-4">token não encontrado</h1>;
  }
  if (!bank) {
    console.log("banco não encontrado");
  }
  // HomeComponent props token, bank
  return (
    <Suspense fallback={<Loader />}>
      <HomeComponent token={token} bank={bank} />;
    </Suspense>
  );
}
