"use client";

import { useIniciadorStatus } from "@/hooks/use-iniciador-status";
import { useRouter, useSearchParams } from "next/navigation";
import * as React from "react";
import { Loader } from "@/components/loader";
import { Suspense } from "react";
import { savePayment } from "@/actions/soapConnection";

function CallbackComponent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const transactionId = searchParams.get("paymentInitiationId") ?? "";

  const [getStatus] = useIniciadorStatus(transactionId);
  //const status = getStatus.status ?? "ENQUEUED";
  const status = getStatus?.data?.metadata?.status;
  const [message, setMessage] = React.useState("aguardando...");
  console.log("paymentId getStatus", status);

  /**
   * 
EXPIRED (Payment expired before is consent created);
CONSENT_REJECTED (Payment rejected by user or consent expired);
PAYMENT_REJECTED (Payment instruction rejected);
ERROR (Validation failure or process error);
CANCELED (Canceled by any other means).

CONSENT_AUTHORIZED (Consent authorized by user);
PAYMENT_PENDING (Consent consumed and Payment transaction is pending);
PAYMENT_PARTIALLY_ACCEPTED (Waiting for multiple authorizations);
PAYMENT_SETTLEMENT_PROCESSING (Payment initiation accepted and payment processing started);
PAYMENT_SETTLEMENT_DEBTOR_ACCOUNT (Debt made to the payer's account);
PAYMENT_COMPLETED (Credit made at the destination account);

   */

  const statusDict: any = {
    STARTED: "Iniciado",
    CONSENT_AWAITING_AUTHORIZATION: "Aguardando consentimento",
    CONSENT_AUTHORIZED: "Consenso autorizado",
    PAYMENT_COMPLETED: "Pagamento efetuado com sucesso",
    ENQUEUED: "aguardando ...",
    CONSENT_REJECTED: "Consenso rejeitado",
    PAYMENT_REJECTED: "Pagamento rejeitado",
    CANCELED: "Pagamento cancelado",
    ERROR: "Erro ao finalizar o pagamento por parte do banco selecionado",
    EXPIRED: "Pagamento expirado",
    PAYMENT_PENDING: "Pagamento pendente, aguardando confirmação bancária",
    PAYMENT_PARTIALLY_ACCEPTED: "Pagamento aguardando multiplas autorizações",
    PAYMENT_SETTLEMENT_PROCESSING:
      "Iniciação de pagamento aceita e processamento de pagamento iniciado",
    PAYMENT_SETTLEMENT_DEBTOR_ACCOUNT: "Crédito realizado na conta de destino",
  };

  React.useEffect(() => {
    if (Object.prototype.hasOwnProperty.call(statusDict, status)) {
      setMessage(statusDict[status]);
    } else {
      setMessage(`Status desconhecido: ${status}`);
    }
  }, [status, getStatus]);

  if (status === "PAYMENT_COMPLETED") {
    // extrair o nrszas do qrcode

    onSavePayment();
    router.push(`/itp/recibo/${transactionId}`);
  }

  async function onSavePayment() {
    await savePayment();
  }

  return (
    <div className="max-w-2xl md:min-w-[600px]">
      <div className="w-full p-4">
        <img
          src="https://poc.billapp.com.br/providers/cemig/logo.svg"
          alt="CEMIG"
          className="w-40 py-5 mb-2"
        />
        <h2 className="text-gray-700 font-bold text-2xl">
          Pagamento de Faturas
        </h2>
      </div>
      <div className="bg-white min-h-[400px] p-6 rounded-lg shadow-lg w-full mb-4 flex flex-col justify-between">
        <div className="text-center">
          <h3 className="text-lg text-black font-bold">Falta pouco!</h3>
          <Loader />
        </div>
      </div>
    </div>
  );
}

export default function CallbackPage() {
  return (
    // You could have a loading skeleton as the `fallback` too
    <Suspense>
      <CallbackComponent />
    </Suspense>
  );
}
