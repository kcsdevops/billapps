import { receiptPayment, statusPayment } from "@/actions/itp-service";
import { Suspense } from "react";
import { Loader } from "@/components/loader";
import Receipt from "./receipt";

// http://localhost:3000/itp/recibo/8adf9a17-6dcc-40cc-b30f-10626641e1a9
// 8adf9a17-6dcc-40cc-b30f-10626641e1a9

export default async function Recibo({ params }: any) {
  const data = await receiptPayment(params.transaction_id);
  console.log(">>::", params.transaction_id, data);
  if (!data) {
    return (
      <div className="flex justify-center items-center w-full h-screen">
        <Loader />
      </div>
    );
  }

  return (
    <Suspense fallback={<Loader />}>
      <div className="flex flex-col md:flex-row w-full">
        <div className="flex w-full flex-col min-h-screen">
          <div className="flex w-full flex-col mt-4 sm:mt-14 items-center justify-center">
            <a href="/">
              <img
                src="https://poc.billapp.com.br/providers/cemig/logo.svg"
                alt="CEMIG"
                className="w-40 py-5 mb-2"
              />
            </a>
            <Receipt data={data} />
          </div>
        </div>
      </div>
    </Suspense>
  );
}
