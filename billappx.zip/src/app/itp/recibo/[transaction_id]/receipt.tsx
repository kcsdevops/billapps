"use client";

import { cn, formatCurrency, formatarHora } from "@/lib/utils";

// http://localhost:3000/cemig1/receipt/11e381c9-e410-4a91-9316-fedb489b3be3

export default async function Receipt({ data, classText = "text-black" }: any) {
  console.log("DATA::", data);
  return (
    <div className="flex w-full flex-col max-w-3xl px-4">
      <div className={cn("my-8", classText)}>
        <h1 className="text-3xl font-bold">Prontinho!</h1>
        <p className="text-2xl">Seu pagamento foi concluido com sucesso.</p>
      </div>
      <span className="shadow-sm bg-white flex flex-col items-stretch pl-3 pr-6 pt-3 pb-5 rounded-lg">
        <span className="flex items-stretch justify-between gap-5">
          <span className="flex grow basis-[0%] flex-col items-stretch">
            <div className="text-black text-base font-medium">CEMIG</div>
            <div className="text-black text-base mt-2 flex flex-col">
              <p className="font-medium text-xs text-neutral-400"></p>
              <p className="font-medium text-base text-neutral-400"></p>
            </div>
            <div className="text-black text-base mt-2.5 flex flex-col">
              <p className="font-medium text-xs text-neutral-400">Descrição:</p>
              <p className="font-medium text-base text-neutral-400">
                operação realizada por Open Finance
              </p>
            </div>
          </span>
          <div className="flex flex-col justify-center items-center text-black text-base font-bold leading-4 self-center my-auto">
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/6da932f5b292583c4918947e36572980b4b3dd9c4ef42b5843bff0ae18f84025?apiKey=6f65d7e2e862460c8ffb4d2909ad4de9&"
              className="aspect-square mb-4 object-contain object-center w-full fill-emerald-400 overflow-hidden max-w-[32px]"
            />
            <div>
              <span className="font-medium text-xs leading-5 text-neutral-400">
                R$
              </span>
              <br />
              <span className="font-semibold text-2xl leading-5">
                {" "}
                {formatCurrency(data?.amount)}
              </span>
            </div>
          </div>
        </span>

        <div className="text-neutral-400 text-xs font-medium whitespace-nowrap mt-4">
          Comprovação do pagamento:
        </div>
        <div className="text-black text-base whitespace-nowrap mt-2">
          {data?.endToEndId}
        </div>
      </span>
    </div>
  );
}
