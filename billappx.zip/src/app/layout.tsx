import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { Toaster } from "react-hot-toast";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/providers/query-provider";
import { JotaiProvider } from "@/providers/jotai-provider";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "CEMIG | Pagar",
  description: "pagamento de fatura com ITP Open Finance",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="flex flex-col items-center min-h-screen bg-gray-100">
          <div className="w-full bg-gradient-to-r from-green-400 to-yellow-300 h-2 fixed top-0 z-10" />

          <QueryClientProvider client={queryClient}>
            <JotaiProvider>
              <Toaster />
              {children}
            </JotaiProvider>
          </QueryClientProvider>

          <div className="text-center text-sm text-gray-600 mt-auto mb-4">
            Desenvolvido pela BillApp Instituição de Pagamentos ltda. Saiba mais
            em{" "}
            <a href="https://www.cemig.com.br/pagar" className="text-blue-500">
              www.cemig.com.br/pagar
            </a>
          </div>
        </div>
      </body>
    </html>
  );
}
