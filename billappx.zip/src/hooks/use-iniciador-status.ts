import { statusPayment } from "@/actions/itp-service";
import { useQuery } from "@tanstack/react-query";

export const useIniciadorStatus = (statusId: string) => {
  const {
    data: getStatus,
    isLoading,
    error,
    refetch: refetchStatus,
  } = useQuery({
    queryKey: ["statusId", "status"],
    queryFn: async () => await statusPayment(statusId),
    refetchInterval: 1500,
  });

  return [getStatus ?? {}, isLoading, error, refetchStatus] as const;
};
