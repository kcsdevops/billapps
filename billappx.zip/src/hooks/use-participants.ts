import { listParticipants } from "@/actions/itp-service";
import { useQuery } from "@tanstack/react-query";

export const useParticipants = () => {
  const {
    data: participants,
    isLoading,
    error,
    refetch: refetchParticipants,
  } = useQuery({
    queryKey: ["participants"],
    queryFn: async () => await listParticipants(),
  });

  return [participants ?? [], isLoading, error, refetchParticipants] as const;
};
