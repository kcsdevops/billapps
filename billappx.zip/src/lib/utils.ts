import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function parseCPF(input: string): string {
  return input.replace(/[.-]/g, "");
}

export function formatDate(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0"); // getMonth() retorna valores de 0 a 11
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

export interface Bank {
  id: string | null;
  name: string | null;
  description: string | null;
  personType: string | null;
  status: string | null;
  slug: string | null;
  avatar: string | null;
  outage: boolean | null;
  outageReason: string | null;
  apiVersion: string | null;
}

export const banks: Bank[] = [
  {
    id: "aaacb9cf-e8c3-402b-93b8-cf4d3e2ec497",
    name: "Santander",
    description:
      "Santander Pessoa Física é a marca do Banco Santander para Pessoas. O Banco atua desde 1982 oferecendo um amplo portfólio de produtos e serviços em seus  canais.",
    personType: "PF",
    status: "ACTIVE",
    slug: "banco-santander-pessoa-fisica",
    avatar:
      "https://storage.googleapis.com/inic-data/banco-santander-pessoa-fisica.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "06c19499-3412-4125-84b7-d0fbc98b5019",
    name: "Nubank",
    description:
      "Simples, transparente e seguro: o Nubank é a empresa líder em tecnologia financeira na América Latina que já reinventou a vida financeira de mais de 40 milhões de clientes com conta digital, cartão de crédito, empréstimo, investimentos, seguros e mais.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "nubank",
    avatar: "https://storage.googleapis.com/inic-data/nubank.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "68308291-ec0d-4398-83ce-68b6b1087e49",
    name: "Itaú",
    description:
      "O Itaú é o maior banco privado do Brasil e está presente em diversos países, contando com empresas no grupo que oferecem crédito, financiamento, investimentos e muito mais. Aproveite o banco completo com soluções que sempre atendem suas necessidades.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "itau",
    avatar: "https://storage.googleapis.com/inic-data/itau.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "439a9b5c-2cfb-4e57-b60b-20eea83899ca",
    name: "Bradesco",
    description:
      "O Bradesco oferece as melhores soluções financeiras, como contas, cartões, investimentos, previdência, seguros, empréstimos, financiamentos, consórcio e muito mais nos Canais Digitais, ajudando clientes dos mais variados perfis a desafiarem o futuro.",
    personType: "PF",
    status: "ACTIVE",
    slug: "bradesco-pessoa-fisica",
    avatar:
      "https://storage.googleapis.com/inic-data/bradesco-pessoa-fisica.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "75db457a-612d-4d62-b557-ba9d32b05216",
    name: "Banco do Brasil",
    description:
      "Acesse serviços bancários e conte com as facilidades BB, seja na web ou no melhor app de banco do país na opinião de usuários. Seu Banco onde e quando você precisar. Para tudo o que você imaginar.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "banco-do-brasil",
    avatar: "https://storage.googleapis.com/inic-data/banco-do-brasil.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "221601a9-6e70-4698-9ea3-1bb28ceb4269",
    name: "CAIXA",
    description:
      "A CAIXA tem as melhores soluções para você e sua empresa. Além de crédito, investimentos, habitação e outros, a CAIXA realiza sonhos e acompanha sua jornada para empreender. Seus dados estão seguros e você tem a solidez do banco de todos os brasileiros.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "caixa",
    avatar: "https://storage.googleapis.com/inic-data/caixa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "756b9782-d9d4-4f9b-9756-997eba0e2cbd",
    name: "PicPay",
    description:
      "O PicPay é uma Instituição de Pagamento que desde 2012 revolucionou a forma como as pessoas lidam com o dinheiro. Com o PicPay você pode receber e enviar dinheiro, guardar dinheiro rendendo mais que a poupança e ter acesso a produtos financeiros.",
    personType: "PF",
    status: "ACTIVE",
    slug: "picpay",
    avatar: "https://storage.googleapis.com/inic-data/picpay.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },

  {
    id: "9326f9b2-ae57-42c4-a0d9-acc4ba434696",
    name: "Mercado Pago",
    description:
      "O Mercado Pago, maior fintech da América Latina, atua no Brasil desde 2004 e tem como missão democratizar o acesso aos serviços financeiros e de pagamentos, contribuindo para a inclusão financeira e fomentando o poder de empreender na região.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "mercado-pago",
    avatar: "https://storage.googleapis.com/inic-data/mercado-pago.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "d7e27a98-ef6c-4b79-b2d8-c2527eba8d84",
    name: "Banco Inter",
    description:
      "Simplicidade pra você e para sua empresa Mais que um banco, uma plataforma de serviços. Conta digital gratuita, plataforma de investimentos, seguros, crédito, shopping, cashback e muito mais!     bancointer.com.br",
    personType: "PF",
    status: "ACTIVE",
    slug: "banco-inter-pf",
    avatar: "https://storage.googleapis.com/inic-data/banco-inter-pf.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "0b86e761-c797-4247-82be-8c6037d723c5",
    name: "Alfa",
    description:
      "O Conglomerado Alfa é composto por empresas atuantes em diversos segmentos do mercado financeiro. Com vasta experiência e tradição, as empresas do Conglomerado Alfa buscam excelência no desenvolvimento de seus negócios.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "alfa",
    avatar: "https://bancoalfa.com.br/institucional/downloads/AlfaLogoAzul.svg",
    outage: true,
    outageReason: "Consentimento com problemas",
    apiVersion: "v3",
  },
  {
    id: "cc26199f-4949-4efd-9e1e-f21a34fd0239",
    name: "Banco Bmg S.A",
    description:
      '"O Banco Bmg S.A é um banco brasileiro, com sede na cidade de São Paulo. Foi fundado em 31 de julho de 1930. Ofereceremos produtos e serviços bancários como: empréstimos, investimentos, cartões para Pessoa Física e Jurídica através do app e site."',
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "banco-bmg-sa",
    avatar: "https://storage.googleapis.com/inic-data/banco-bmg-sa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "498f0d4f-3ff7-4010-a43f-f59c63680f27",
    name: "Banco da Amazônia",
    description:
      "O BASA atua desde 1942 sendo o principal agente de crédito de fomento da região Amazônica, oferecendo também serviços de pagamento e produtos de investimento para os clientes pessoas físicas e jurídicas.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "banco-da-amazonia",
    avatar: "https://storage.googleapis.com/inic-data/banco-da-amazonia.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "f9cabb03-876d-4eea-974c-0d8ce4bd4860",
    name: "banco Digio",
    description:
      "O Digio é mais que um banco digital, é uma bantech. Pois conta com a solidez de um banco e agilidade de uma fintech. Com tecnologia, buscamos cumprir nossa principal missão: transformar a vida financeira dos brasileiros com segurança e transparência.",
    personType: "PF",
    status: "ACTIVE",
    slug: "banco-digio",
    avatar: "https://storage.googleapis.com/inic-data/banco-digio.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "c308d06e-65d1-4aab-997d-4e9f0e8f3129",
    name: "Banco Genial",
    description:
      "O Banco Genial é um banco múltiplo com foco em operações estruturadas de financiamento, assessoria financeira, operações de crédito, câmbio e asset management. Possui uma forte atuação na prestação de serviços no mercado de capitais para atacado e varejo.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "banco-genial",
    avatar:
      "https://media-genial-cms.genialinvestimentos.com.br/wp-content/uploads/2021/08/20161050/logo-genial.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "b1e292ec-3d2d-4cdd-b175-77e1d33dd24b",
    name: "Banco Master S.A.",
    description:
      "Um banco dinâmico, ágil, fácil e moderno. Aqui você conta com soluções para facilitar sua vida ﬁnanceira, com autonomia e agilidade, a qualquer hora e em qualquer lugar. Banco Master: seu sucesso, nossa maior conquista!",
    personType: "N/A",
    status: "ACTIVE",
    slug: "banco-master-sa",
    avatar: "https://storage.googleapis.com/inic-data/banco-master-sa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "612da9a3-ee82-4f9e-9919-fa8ba88800f9",
    name: "Banco PAN",
    description:
      "O Banco PAN tem o objetivo de trazer um novo olhar para os desafios financeiros do brasileiro por meio de um portfólio de produtos: conta digital, cartão de crédito, empréstimos, financiamento de veículos e mais.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "banco-pan",
    avatar: "https://storage.googleapis.com/inic-data/banco-pan.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "8dd11bd5-165e-4662-9eaa-112ef0d499c0",
    name: "Banco XP S.A.",
    description:
      "O Banco XP é um banco múltiplo que tem as melhores soluções financeiras, tais como: conta corrente, cartão de crédito, Investback, benefícios em lojas parceiras, empréstimos, câmbio e muito mais, pensando em você e também no seu negócio!",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "banco-xp-sa",
    avatar: "https://storage.googleapis.com/inic-data/banco-xp-sa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "18ce9615-81de-4aaa-8671-e8a95d570fb8",
    name: "Banestes SA",
    description:
      "O Banestes S.A. - Banco do Estado do Espírito Santo (B3: BEES3, BEES4), sociedade anônima de capital aberto e de economia mista criada em 1937, é um banco múltiplo controlado pelo estado do Espírito Santo. Detém a maior rede bancária do estado.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "banestes-sa",
    avatar: "https://storage.googleapis.com/inic-data/banestes-sa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "88dc57a4-1dab-4493-8b02-b8f0c15a2d89",
    name: "Banrisul",
    description:
      "Seja na facilidade do Banrisul Digital ou em uma das 500 agências espalhadas pelo Rio Grande do Sul e pelo Brasil, o Banrisul é o parceiro ideal para você e para o seu negócio. Compartilhe os seus dados com o Banrisul.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "banrisul",
    avatar: "https://storage.googleapis.com/inic-data/banrisul.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "40463326-a162-4b44-9afe-7803a6554e31",
    name: "BRB - Banco de Brasilia SA",
    description:
      "No mundo digital, o BRB dispõe de serviços e produtos bancários tanto no celular quanto na internet. No mundo físico, são mais de 45 mil pontos de autoatendimento e a rede de bancos 24h à sua disposição. Há 55 anos transformando vidas e realizando sonhos.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "brb-banco-de-brasilia-sa",
    avatar:
      "https://storage.googleapis.com/inic-data/brb-banco-de-brasilia-sa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "b397dd9c-62b2-4632-bce7-85f56666c083",
    name: "BTG Banking",
    description:
      "O BTG Banking é um banco completo, uma plataforma que aprende com você e entende as suas necessidades para entregar soluções financeiras inteligentes que resolvem o seu dia a dia enquanto você planeja o seu futuro.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "btg-banking",
    avatar: "https://storage.googleapis.com/inic-data/btg-banking.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "6a0ec228-70b7-4292-9e64-8fa731b2a730",
    name: "C6 Bank",
    description:
      "Experimente o C6 Bank! Garanta sua conta e tenha uma relação mais saudável com o seu dinheiro. Conta 100% digital em um app rápido e em constante evolução. Baixe o app. Sem anuidade. Saque sem tarifa. Saques gratuitos. Abra sua Conta.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "c6-bank",
    avatar: "https://storage.googleapis.com/inic-data/c6-bank.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "fe1bd3c6-8252-4d03-8d65-03ebd34c678f",
    name: "CrediSIS",
    description:
      "O CrediSIS é um Sistema de Crédito Cooperativo, criado em 13 de agosto de 2000, através das cooperativas filiadas. Nossa missão é prover soluções financeiras aos cooperados, fomentando o cooperativismo e contribuindo para o desenvolvimento da sociedade.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "credisis",
    avatar: "https://storage.googleapis.com/inic-data/credisis.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "408f1bc6-4c6e-4938-8082-003a085f86f6",
    name: "Cresol",
    description:
      "A Cresol é uma cooperativa que fornece soluções financeiras para toda a comunidade. Nasceu em 1995 com o objetivo de fazer a diferença. O Sistema Cresol está presente em 17 estados e se destaca como uma das principais cooperativas de crédito do Brasil",
    personType: "N/A",
    status: "ACTIVE",
    slug: "cresol",
    avatar: "https://storage.googleapis.com/inic-data/cresol.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "051a52a4-711d-49a9-8452-0f4b35871482",
    name: "Daycoval",
    description:
      "O Banco Daycoval é uma instituição financeira de mais de 50 anos no mercado especializada em crédito para empresas, para pessoa física (consignado e financiamento), produtos de câmbio e investimentos, tendo canais de atendimento físicos e digitais.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "daycoval",
    avatar: "https://cdn.daycoval.com.br/obbr/daycoval.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "ebbed125-5cd7-42e3-965d-2e7af8e3b7ae",
    name: "Efí S.A.",
    description:
      "A Efí é tudo que o empreendedor precisa: Conta Digital com cartão de débito e pré-pago, emissão de boletos, carnês e links de pagamento, Pix, APIs de recebimento, gestão de clientes e atendimento exclusivo de segunda a segunda, das 07h às 22h.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "efi-sa",
    avatar: "https://storage.googleapis.com/inic-data/efi-sa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "8197a3c9-11ad-4cfd-9bbf-4d6ad5d51f83",
    name: "Iti",
    description:
      "O iti é o banco digital grátis do Itaú que você abre sua conta em até 4 minutos, sem comprovar renda e endereço. No app você paga suas contas, recebe e faz Pix, tem cartão de crédito físico/virtual e pode ter empréstimo com parcelas que cabem no seu bolso",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "iti",
    avatar: "https://storage.googleapis.com/inic-data/iti.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "dcd4560f-574e-43ff-93a3-a4b4e5106899",
    name: "MEI Fácil",
    description: "Authorisation Server MEI Fácil",
    personType: "N/A",
    status: "ACTIVE",
    slug: "mei-facil",
    avatar: "https://opbk-brasil.s3.sa-east-1.amazonaws.com/meifacil/logo.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "7a7a9a8d-f086-44b6-b81e-215d516c27c1",
    name: "Midway",
    description:
      "A Midway é uma plataforma de bem estar financeiro. Através da conta digital gratuita, os consumidores podem ter acesso a empréstimos facilitados, seguros e assistências, ter seu dinheiro rendendo todo dia, sorteios mensais de R$ 10.000 e muito mais!",
    personType: "N/A",
    status: "ACTIVE",
    slug: "midway",
    avatar: "https://storage.googleapis.com/inic-data/midway.svg",
    outage: true,
    outageReason: "Erro no consentimento",
    apiVersion: "v3",
  },
  {
    id: "3f15766b-4fc1-4d22-b6ee-5eb05d6cec8f",
    name: "Neon",
    description: "Authorisation Server Neon",
    personType: "N/A",
    status: "ACTIVE",
    slug: "neon",
    avatar: "https://storage.googleapis.com/inic-data/neon.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "ba185564-2e26-420e-b6bb-af5bc7102480",
    name: "next",
    description:
      "O next é um banco digital completo e gratuito, criado para facilitar a vida das pessoas e ajudá-las a conquistar seus objetivos. Além de conta-corrente e cartões, oferece investimentos, crédito, empréstimos, seguros e promoções com lojas parceiras.",
    personType: "PF",
    status: "ACTIVE",
    slug: "next",
    avatar: "https://storage.googleapis.com/inic-data/next.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "4a417c4c-b7e5-49eb-926e-b257f3647fff",
    name: "Orbi Bank",
    description:
      "Somos o Orbi Bank, aplicativo da Realize, instituição financeira da Lojas Renner S.A.. Desenvolvemos soluções pensando no que o nosso cliente precisa e do jeito que ele prefere, atuando no mercado à mais de 5 anos.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "orbi-bank",
    avatar: "https://openfinance.realizesolucoesfinanceiras.com.br/logo.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "3557f9f7-897a-45a2-9b3b-86a9eb8061dd",
    name: "Ourinvest",
    description:
      "40 anos de história e referência no mercado. Nosso objetivo é entender o cliente para oferecer soluções completas e atendimento personalizado para que eles possam realizar com tranquilidade e segurança suas operações cambiais.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "ourinvest",
    avatar: "https://storage.googleapis.com/inic-data/ourinvest.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "649ffe9a-503d-4635-a0fd-41f4b5135b6c",
    name: "PagBank",
    description:
      "O PagSeguro é uma empresa líder da internet brasileira, possui em seu portfolio soluções de pagamentos para o comércio eletrônico, atendendo lojas virtuais, e também para estabelecimentos comerciais.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "pagbank",
    avatar: "https://storage.googleapis.com/inic-data/pagbank.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "a26fd41e-cad0-4934-b082-4b79668e3aeb",
    name: "PARANÁ BANCO",
    description:
      "Nosso propósito é transformar soluções financeiras em sorrisos",
    personType: "N/A",
    status: "ACTIVE",
    slug: "parana-banco",
    avatar:
      "https://prbportaissites.blob.core.windows.net/portalinstitucional/2023/11/PB_Sorriso.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "10b4f3da-e04e-4904-9988-e93c8f141ab1",
    name: "QI SCD",
    description:
      "A QI SCD atua desde 2019 no mercado de crédito brasileiro. Nosso foco é bancarizar empresas que desejam operar crédito com seus clientes",
    personType: "N/A",
    status: "ACTIVE",
    slug: "qi-scd",
    avatar: "https://storage.googleapis.com/inic-data/qi-scd.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "66c11181-42ad-4a3b-894c-8db9b224874d",
    name: "Quero-Quero PAG",
    description:
      "Com o Quero-Quero PAG você tem uma conta digital completa, com Pix, cartões de débito e crédito, empréstimos, seguro e tudo mais que você precisar. Somos uma empresa do grupo Quero-Quero.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "queroquero-pag",
    avatar:
      "https://api.queroquero.com.br/webapps/assets/assets/logo/icone_QQPag.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "bfd95599-61c0-45ca-90cb-5d6e71d4cf9a",
    name: "Safra PF",
    description:
      "O Banco Safra S.A. é referência em tradição e segurança no mercado financeiro e oferece um portfólio de produtos e serviços completo para seus clientes.",
    personType: "PF",
    status: "ACTIVE",
    slug: "safra-pf",
    avatar: "https://storage.googleapis.com/inic-data/safra-pf.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "c2d48e71-07af-4442-8c7d-c82d0eb45e5f",
    name: "Sicoob",
    description:
      "O Sicoob é uma instituição financeira cooperativa que está presente em todos os estados brasileiros e conta com um portfólio completo de produtos e serviços financeiros, além de taxas bem mais justas que as encontradas no mercado financeiro convencional.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "sicoob",
    avatar: "https://storage.googleapis.com/inic-data/sicoob.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "6c8b9aed-8e24-4ad6-985f-213623a23be3",
    name: "Sicredi",
    description:
      "O Sicredi é uma instituição financeira cooperativa, há 120 anos valorizando o relacionamento, o crescimento em conjunto e a participação nos resultados. Facilitamos sua rotina com um atendimento próximo e soluções para você, sua empresa ou agronegócio.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "sicredi",
    avatar: "https://storage.googleapis.com/inic-data/sicredi.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "b096d65c-159f-4e3d-b23b-c7e62fc64479",
    name: "Superdigital",
    description:
      "Operando desde 2012, a Superdigital Santander é uma conta digital pré-paga que busca simplificar a vida de seus clientes oferecendo facilidades como cartão da conta, transações de pagamentos: pix, transferências, depósitos.",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "superdigital",
    avatar:
      "https://superdigital.com.br/assets/img/img/logo_super_512x512px.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "7f2249e4-8d3d-4133-8c19-4c54c62459fa",
    name: "U4C",
    description:
      "U4C - Bank as a Platform: Soluções para Bancos Digitais, cobranças Pix e Iniciação de Pagamento Whitelabel.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "u4c",
    avatar: "https://storage.googleapis.com/inic-data/u4c.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "646b2dc7-3a9e-4d2e-9ded-665e7150d529",
    name: "Unicred",
    description:
      "O Sistema Unicred nasceu em 1989 com o propósito de levar prosperidade à vida de todos os cooperados. Possuímos atendimento qualificado, baseado em assessoria financeira e preços justos através dos nossos canais físicos e digitais. Seja Open com a Unicred",
    personType: "PF|PJ",
    status: "ACTIVE",
    slug: "unicred",
    avatar: "https://storage.googleapis.com/inic-data/unicred.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "74f9cbfb-1016-4558-a78c-5a55814ce52a",
    name: "Woop",
    description:
      "O Woop é a conta digital com tudo o que você precisa para descomplicar a sua vida financeira e ainda ajudar no desenvolvimento da sua região. Você também conta com cartão de crédito, carteiras digitais e muito mais.",
    personType: "N/A",
    status: "ACTIVE",
    slug: "woop",
    avatar: "https://storage.googleapis.com/inic-data/woop.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
  {
    id: "2ba35e89-a932-469f-85c5-4a0ba8b28304",
    name: "ZEMA CFI S/A",
    description:
      "A Zema Financeira é o braço financeiro do Grupo Zema, um dos grupos empresariais mais sólidos do Brasil, que possui mais de 98 anos de história, tradição e reconhecimento.  ",
    personType: "N/A",
    status: "ACTIVE",
    slug: "zema-cfi-sa",
    avatar: "https://storage.googleapis.com/inic-data/zema-cfi-sa.svg",
    outage: false,
    outageReason: null,
    apiVersion: "v3",
  },
];

export function getBankById(id: string): Bank | undefined {
  return banks.find((bank) => bank.id === id);
}

export function convertStringToNumber(valueString: string): number {
  // Remove a vírgula ou o ponto
  const cleanedValueString = valueString.replace(/,|\./g, "");

  // Converte a string em um número
  const valueNumber = parseInt(cleanedValueString);

  return valueNumber;
}

export function decode_brcode(brcode: any, recursivamente = true) {
  let n = 0;
  let retorno: any = {};
  while (n < brcode.length) {
    let codigo = brcode.substring(n, n + 2);
    n += 2;
    let tamanho = parseInt(brcode.substring(n, n + 2));
    if (isNaN(tamanho)) {
      return false;
    }
    n += 2;
    let valor = brcode.substring(n, n + tamanho);
    n += tamanho;
    if (codigo == "26") {
      retorno["26"] = decode_brcode(valor, false);
    } else if (recursivamente && /^[0-9]{4}.+$/.test(valor) && codigo != "54") {
      retorno[codigo] = decode_brcode(valor);
    } else {
      retorno[codigo] = valor;
    }
  }
  return retorno;
}

export function formatCurrency(number: number): string {
  const formattedNumber = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(number / 100);

  return formattedNumber;
}

export function formatarHora(dataString: string): string {
  const data = new Date(dataString);

  // Obtém horas e minutos da data
  const horas = data.getHours();
  const minutos = data.getMinutes();

  // Formata as horas e minutos para o formato desejado (HH:mm)
  const horasFormatadas = horas < 10 ? `0${horas}` : `${horas}`;
  const minutosFormatados = minutos < 10 ? `0${minutos}` : `${minutos}`;

  // Retorna a string formatada
  return `às ${horasFormatadas}:${minutosFormatados}`;
}

export function getFirstName(fullname: string | null) {
  const name = fullname?.trim();
  if (!name) return;
  return name.split(" ")[0];
}
