import { atom } from "jotai";

const User = {
  nomeCliente: null,
  documentoCliente: null,
  pix: null,
};

export const userAtom = atom<any>(User);
