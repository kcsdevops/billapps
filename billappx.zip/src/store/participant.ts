import { Bank } from "@/lib/utils";
import { atomWithStorage } from "jotai/utils";

const Participant: Bank = {
  id: null,
  name: null,
  description: null,
  personType: null,
  status: null,
  slug: null,
  avatar: null,
  outage: null,
  outageReason: null,
  apiVersion: null,
};
export const participantAtom = atomWithStorage("participant", Participant);
