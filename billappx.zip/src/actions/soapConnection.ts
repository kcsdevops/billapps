"use server";

import fs from "fs";
import forge from "node-forge";
import https from "https";
import { parseStringPromise } from "xml2js";

// Configurações
const usuario = process.env.USUARIO!;
const senha = process.env.SENHA!;
const certificadoPath = "actions/pgto.cemig.com.br.cert.pfx";
const certificadoSenha = process.env.CERFIFICADO_SENHA!;

function loadPfx(filename: string, password: string) {
  const pfx = fs.readFileSync(filename);
  const asn1 = forge.asn1.fromDer(pfx.toString("binary"));
  const p12 = forge.pkcs12.pkcs12FromAsn1(asn1, false, password);

  const keyBags = p12.getBags({ bagType: forge.pki.oids.pkcs8ShroudedKeyBag });
  const certBags = p12.getBags({ bagType: forge.pki.oids.certBag });

  const keyBagArray = keyBags[forge.pki.oids.pkcs8ShroudedKeyBag];
  const certBagArray = certBags[forge.pki.oids.certBag];

  if (!keyBagArray || keyBagArray.length === 0) {
    throw new Error("Private key bag not found in PFX file.");
  }

  if (!certBagArray || certBagArray.length === 0) {
    throw new Error("Certificate bag not found in PFX file.");
  }

  const privateKeyBag = keyBagArray[0];
  const certBag = certBagArray[0];

  if (!privateKeyBag.key) {
    throw new Error("Private key not found in PFX file.");
  }

  if (!certBag.cert) {
    throw new Error("Certificate not found in PFX file.");
  }

  const privateKey = forge.pki.privateKeyToPem(privateKeyBag.key);
  const cert = forge.pki.certificateToPem(certBag.cert);

  return { key: privateKey, cert: cert };
}

// Carrega o certificado
let certInfo: any;
try {
  certInfo = loadPfx(certificadoPath, certificadoSenha);
} catch (error) {
  console.error("Erro ao carregar o certificado:", error);
  process.exit(1);
}

// token: STVY | cpfCnpj3: 012

export async function loadUserData(token: string, cpfCnpj: string) {
  const envelope = `
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
      xmlns:pag="http://cemig.com.br/soa/negocio/comercial/Pagamento/">
        <soapenv:Header/>
        <soapenv:Body>
          <pag:retornarPIXRequest>
              <canalAtendimento>AGV</canalAtendimento>
              <codigoNRZAS></codigoNRZAS>
              <token>${token}</token>
              <cpfCnpj3>${cpfCnpj}</cpfCnpj3>
          </pag:retornarPIXRequest>
        </soapenv:Body>
    </soapenv:Envelope>`;

  const options = {
    hostname: "pgto.cemig.com.br",
    port: 443,
    path: "/qas/negocio/comercial/pagamento/pagamentoService",
    method: "POST",
    headers: {
      "Content-Type": "text/xml;charset=UTF-8",
      SOAPAction: "retornarPIX",
      Authorization:
        "Basic " + Buffer.from(usuario + ":" + senha).toString("base64"),
    },
    key: certInfo.key,
    cert: certInfo.cert,
    rejectUnauthorized: false, // Use com cuidado em ambientes de produção
  };

  //console.log("options>>>>", options);
  //console.log("envelope>>>>", envelope);

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = "";

      res.on("data", (chunk) => {
        data += chunk;
      });

      res.on("end", async () => {
        console.log("Resposta da API:");
        console.log(data);

        try {
          // Converte a resposta XML para JSON
          const result = await parseStringPromise(data);

          // Extrai os valores desejados do JSON resultante
          const responseData =
            result["soapenv:Envelope"]["soapenv:Body"][0][
              "out4:retornarPIXResponse"
            ][0]["dadosPagamento"][0];
          const nomeCliente = responseData["nomeCliente"][0];
          const documentoCliente = responseData["documentoCliente"][0];
          const pix = responseData["pix"][0];

          // Cria o objeto JSON
          const jsonResponse = {
            nomeCliente,
            documentoCliente,
            pix,
          };

          console.log("Resposta em JSON:");
          console.log(jsonResponse);

          resolve(jsonResponse);
        } catch (err) {
          console.error("Erro ao converter XML para JSON:", err);
          reject(err);
        }
      });
    });

    req.on("error", (err) => {
      console.error("Erro:", err);
      reject(err);
    });

    // Enviar o envelope SOAP
    req.write(envelope);
    req.end();
  });
}

export async function savePayment() {
  const date = "2020-12-18T18:07:08.000Z";
  const apiKey = process.env.NRSAZ_API_KEY;
  const formularioPagamento = "wbNhU2u4R.0"; // NRSAZ
  const identificadorParceiroNegocio = "765675765";
  const SOAPAction = "retornarPIX";

  const envelope = `
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pag="http://cemig.com.br/soa/negocio/comercial/Pagamento/">
   <soapenv:Header/>
   <soapenv:Body>
      <pag:efetuarBaixaPagamentoRequest>
         <!--Optional:-->
         <canalAtendimento>AGV</canalAtendimento>
         <identificadorParceiroNegocio>${identificadorParceiroNegocio}</identificadorParceiroNegocio>
         <formularioPagamento>${formularioPagamento}</formularioPagamento>
         <tipoPagamento>credit</tipoPagamento>
         <status>APPROVED</status>
         <apiKey>${apiKey}</apiKey>
      </pag:efetuarBaixaPagamentoRequest>
   </soapenv:Body>
</soapenv:Envelope>`;

  const options = {
    hostname: "pgto.cemig.com.br",
    port: 443,
    path: "/qas/negocio/comercial/pagamento/pagamentoService",
    method: "POST",
    headers: {
      "Content-Type": "text/xml;charset=UTF-8",
      SOAPAction,
      Authorization:
        "Basic " + Buffer.from(usuario + ":" + senha).toString("base64"),
    },
    key: certInfo.key,
    cert: certInfo.cert,
    rejectUnauthorized: false, // Use com cuidado em ambientes de produção
  };

  //console.log("options>>>>", options);
  //console.log("envelope>>>>", envelope);

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = "";

      res.on("data", (chunk) => {
        data += chunk;
      });

      res.on("end", async () => {
        console.log("Resposta da API:");
        console.log(data);

        try {
          // Converte a resposta XML para JSON
          const result = await parseStringPromise(data);

          // Extrai os valores desejados do JSON resultante
          const responseData =
            result["soapenv:Envelope"]["soapenv:Body"][0][
              "out4:retornarPIXResponse"
            ][0]["dadosPagamento"][0];
          const nomeCliente = responseData["nomeCliente"][0];
          const documentoCliente = responseData["documentoCliente"][0];
          const pix = responseData["pix"][0];

          // Cria o objeto JSON
          const jsonResponse = {
            nomeCliente,
            documentoCliente,
            pix,
          };

          console.log("Resposta em JSON:");
          console.log(jsonResponse);

          resolve(jsonResponse);
        } catch (err) {
          console.error("Erro ao converter XML para JSON:", err);
          reject(err);
        }
      });
    });

    req.on("error", (err) => {
      console.error("Erro:", err);
      reject(err);
    });

    // Enviar o envelope SOAP
    req.write(envelope);
    req.end();
  });
}

/*
00020126870014br.gov.bcb.pix0136dce71622-c425-4f3c-989d-34853baf9a720225Documento Cob. de Debitos5204000053039865406202.205802BR5908CEMIG D.6014Belo Horizonte6229052500069172319600000000242576304023B
*/
