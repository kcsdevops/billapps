"use server";

import { v4 as uuidv4 } from "uuid";
import { cookies } from "next/headers";
import { parseCPF } from "@/lib/utils";

const BASE_URL = process.env.BASE_URL ?? "";
const API_URL = process.env.API_URL ?? "";

const headers = {
  accept: "*/*",
  "content-type": "application/json",
};

export async function listParticipants(): Promise<any[]> {
  const cookieStore = cookies();
  const accessToken = cookieStore.get("sessionJwt")?.value;
  const path = `${API_URL}/participants`;
  try {
    const _headers = {
      ...headers,
      authorization: `Bearer ${accessToken}`,
    };
    const req = await fetch(path, {
      method: "GET",
      headers: { ..._headers },
    });
    const { data } = await req.json();
    console.log("listParticipants", path, data);
    return data;
  } catch (error) {
    throw new Error("error get participants");
  }
}

export async function initPaymentQRCode(_data: any) {
  console.log("initPaymentQRCode", _data);

  let data = { ..._data };
  if (!data.amount) {
    return;
  }

  if (process.env.APP_ENV === "development") {
    data.codePix =
      "00020101021126360014br.gov.bcb.pix0114929588000001385204000053039865802BR5923SOS - Rio Grande do Sul6012PORTO ALEGRE62070503***6304A3D3";
    data.amount = 1;
  }
  const accessToken = "";
  const path = `${API_URL}/payments/qrcode`;
  const payload = {
    user: {
      name: data.name,
      taxId: parseCPF(data.taxId),
    },
    externalId: uuidv4(),
    participantId: data.participantId,
    method: "PIX_QRCODE",
    redirectURL: `${BASE_URL}/${data.redirectURL}`,
    redirectOnErrorURL: `${BASE_URL}/${data.redirectURL}`,
    qrCode: data.codePix,
    amount: data.amount,
  };
  try {
    const _headers = {
      ...headers,
      authorization: `Bearer ${accessToken}`,
    };
    const req = await fetch(path, {
      method: "POST",
      headers: { ..._headers },
      body: JSON.stringify(payload),
    });
    const response = await req.json();
    console.log("initPaymentQRCode", response);
    return response.id;
  } catch (error) {
    throw new Error("error get initPayment");
  }
}

export async function statusPayment(paymentId: string) {
  console.log("statusPayment");
  const cookieStore = cookies();
  const accessToken = cookieStore.get("sessionJwt")?.value;
  let path = `${API_URL}/webhook/${paymentId}`;

  try {
    const _headers = {
      ...headers,
      authorization: `Bearer ${accessToken}`,
    };
    const req = await fetch(path, {
      method: "GET",
      headers: { ..._headers },
    });
    if (process.env.APP_ENV === "development") {
      const { data } = await req.json();
      console.log("statusPayment", data);
      return data;
    }
    const data = await req.json();
    console.log("statusPayment", data);
    return data;
  } catch (error) {
    throw new Error(`error get statusPayment:: ${error}`);
  }
}

export async function receiptPayment(paymentId: string) {
  const cookieStore = cookies();
  const accessToken = cookieStore.get("sessionJwt")?.value;
  //const accessToken = await authenticationWithoutCookie();
  const path = `${API_URL}/payments/${paymentId}`;
  try {
    const _headers = {
      ...headers,
      authorization: `Bearer ${accessToken}`,
    };
    const req = await fetch(path, {
      method: "GET",
      headers: { ..._headers },
    });
    const data = await req.json();
    return data;
  } catch (error) {
    throw new Error("error get receiptPayment");
  }
}
